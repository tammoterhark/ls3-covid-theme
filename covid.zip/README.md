# ls3-covid-theme
Theme for "Your COVID-19 Risk" project, using Limesurvey3 software
The theme is based on the Vanilla theme for LimeSurvey 3.x
Has been tested in LimeSurvey 3.22.8(200309)

Contributors:
Jan Ehrhardt (Tools for Research): javascript additions
Tammo ter Hark (Respondage): setup, styling
Stefan Verweij (Evently): code review, add logo